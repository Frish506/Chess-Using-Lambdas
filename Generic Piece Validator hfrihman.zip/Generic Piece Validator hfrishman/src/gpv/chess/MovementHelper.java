package gpv.chess;

public class MovementHelper {

}
